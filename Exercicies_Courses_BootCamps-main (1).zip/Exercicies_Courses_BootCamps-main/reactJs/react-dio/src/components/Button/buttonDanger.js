const ButtonDanger =(props) =>{
    return(
        <button type="button" class="btn btn-danger" onClick = {props.onClick}>Danger</button>
    )
}
export default ButtonDanger;