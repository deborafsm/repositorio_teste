const ButtonSuccess = (props) => {
    return(
        
        <button 
        type="button" class="btn btn-success" onClick = {props.onClick}>Success</button>

    )
}


export default ButtonSuccess;


